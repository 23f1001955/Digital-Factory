# Freelance Daily Task Dashboard

```markdown
# 🎯 Today's Mission: [Date]
## 💡 Top 3 Priorities
1. [Most Important Task] - **Deadline:** [Time/Date]
2. [Second Priority] - **Deadline:** [Time/Date]
3. [Third Priority] - **Deadline:** [Time/Date]

## 📅 Scheduled Blocks
- **Deep Work:** [9:00 - 11:30] → [Focus Task]
- **Client Comms:** [14:00 - 15:00] → [Calls/Emails]
- **Admin/Finance:** [16:30 - 17:30] → [Invoicing/Follow-ups]

## 📥 Inbox & Quick Capture
- [ ] Client request: [Details]
- [ ] New inquiry: [Source]
- [ ] Inspiration find: [Link/Note]

## 🔥 Current Focus
**Active Project:** [Project Name]  
**What to finish next:** [Specific next action]  
**Energy level:** ⭐⭐⭐ (⭐ Low → ⭐⭐⭐ High)

## 🚫 Avoid Today
- [Time-waster/distraction]
- [Non-urgent task]
```

---

# Client Communication Log

```markdown
# 📧 Client Comms Tracker: [Week of Date]
## 🚀 Today's Connections
| Client | Project | Status | Action Needed | Follow-up By |
|--------|---------|--------|---------------|--------------|
| [Name] | [Project] | 📨 Replied | Send revised mockup | [Date] |
| [Name] | [Project] | 📞 Called | Send proposal | [Date] |

## ✉️ Pending Responses
1. **To:** [Client]  
   **Subject:** [Topic]  
   **Sent:** [Date]  
   **Waiting since:** [Days]  
   **Next step:** [Polite follow-up/email]

## 💬 Key Questions Received
- [Client question about scope] → [Your answer]
- [Feedback on draft] → [Action taken]

## 📆 Scheduled Check-ins
- **[10:00]** Project update call with [Client]
- **[14:30]** Feedback review with [Client]

## 📝 Communication Wins
- [Positive feedback received]
- [Relationship strengthened]
```

---

# End-of-Day Shutdown & Planning

```markdown
# 🌙 Daily Shutdown: [Date]
## ✅ Today's Wins
- [Completed task] (took [time/energy])
- [Achievement] (impacted [project/result])
- [Unexpected win] 

## 📊 Metrics
- **Hours focused:** [X]  
- **Client tasks completed:** [X]  
- **Billable hours:** [X]  
- **New contacts:** [X]

## 🔄 Carry Over (Unfinished)
- [Task] → **Tomorrow priority:** [High/Medium/Low]
- [Task] → **Why incomplete:** [Blocker/Time]

## 💡 Today's Insights
- [Lesson learned about process]
- [Observation about client]
- [Personal productivity note]

## 📅 Tomorrow's Preparation
1. **First task of day:** [Specific action]
2. **Key deadline:** [Important item]
3. **Energy plan:** [High-energy task scheduled for...]
4. **Quick win to start:** [Small satisfying task]

## 🧠 Brain Dump
[Free-form notes, worries, ideas - no structure needed]
```

---

**How to use:**  
1. Copy the template you need into your note-taking app  
2. Replace `[bracketed items]` with your specific details  
3. Use the checkboxes for daily tracking  
4. Adapt sections to your workflow - these are starting points, not rigid rules  

These templates balance structure with flexibility, addressing the core needs of freelance designers: task prioritization, client communication, and end-of-day reflection. The key is consistency over perfection—use what serves you and discard what doesn’t.