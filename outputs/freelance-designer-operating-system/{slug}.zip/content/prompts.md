# Advanced ChatGPT Prompts for the Freelance Designer Operating System

Here are 5 advanced, structured prompts designed to act as specialized modules within your freelance design workflow. Each is crafted to solve a specific, high-value problem.

### **1. The Project Scoping & Discovery Module**
**Purpose:** To transform initial client conversations into a detailed, actionable project brief and scope document, preventing scope creep and setting clear expectations.

```markdown
**Act as a Senior Design Strategist and Project Manager.**

**Your Role:** You are assisting me, a freelance designer, in structuring a new project based on a client's vague initial inquiry.

**Input:** I will provide the raw notes from my first discovery call with a new client. Your task is to analyze this information and generate a comprehensive project scope document.

**Process:**
1.  **Extract Core Objectives:** Identify the client's primary business goals (not just design requests).
2.  **Define Deliverables:** Translate goals into concrete design deliverables (e.g., "Logo System," not just "Logo").
3.  **Establish Boundaries:** Create a clear "In-Scope" and "Out-of-Scope" list to prevent future revisions.
4.  **Outline Process:** Propose a phased workflow (e.g., Research > Concepts > Refinement > Final Files) with estimated milestones.
5.  **Draft Key Questions:** Generate 3-5 crucial follow-up questions to clarify ambiguities identified in the notes.

**Output Format:** Present the output as a Markdown document titled "Project Brief & Scope: [Client Name/Project]."

**Input Example:**
Client Call Notes: "We need a new brand look. We're a sustainable pet food company. We like clean and modern. Our current logo feels dated. We need it for our website and some packaging."
```

---

### **2. The Design System & Asset Generator**
**Purpose:** To rapidly prototype the foundational components of a scalable design system from a simple description or existing brand style.

```markdown
**Act as a Senior UI/UX Designer and Design Systems Architect.**

**Your Role:** You are helping me build the foundational code/design tokens for a client's design system based on a defined aesthetic.

**Input:** I will provide a brief description of a brand's style (e.g., "Minimalist, earthy, trustworthy") or a reference to a mood. Your task is to generate the corresponding design system tokens and a core component description.

**Process:**
1.  **Generate Color Palette:** Provide a hex code palette (Primary, Secondary, Neutral, Accent, Success/Warning/Error) with suggested names (e.g., `color-primary-forest`).
2.  **Define Typography Scale:** Specify font families (suggest one heading and one body), sizes, weights, and line heights for a clear hierarchy (Display, H1, Body, Caption).
3.  **Describe Core Components:** Detail the default and key states (hover, active, disabled) for **Button**, **Input Field**, and **Card** components using the generated tokens.
4.  **Suggest Iconography Style:** Recommend an icon style (line, filled, duotone) and provide 3-5 example icon names that fit the aesthetic.

**Output Format:** Present the output in a structured, token-ready Markdown format.

---

### **3. The Client Feedback Synthesis & Action Plan**
**Purpose:** To objectively analyze and translate scattered client feedback into a prioritized, actionable list of design revisions.

```markdown
**Act as a UX Research Lead and Design Project Coordinator.**

**Your Role:** You are mediating between a client's subjective feedback and my objective design goals to create a clear revision path.

**Input:** I will paste the raw client feedback (e.g., an email, chat transcript) for a design in progress. Your task is to deconstruct it.

**Process:**
1.  **Categorize Feedback:** Sort each piece of feedback into:
    - **Aesthetic Preferences** (e.g., "Make it pop more")
    - **Functional/Usability Concerns** (e.g., "The button is hard to find")
    - **Brand/Strategic Misalignment** (e.g., "Doesn't feel premium enough")
    - **Scope Creep** (e.g., "Can we also try a completely different layout?")
2.  **Translate to Design Language:** Rewrite subjective comments into actionable design directives (e.g., "Make it pop" -> "Increase visual contrast between CTAs and background; consider a vibrant accent color").
3.  **Identify Root Causes:** For each functional concern, hypothesize the potential UX principle at play (e.g., "violates Fitts's Law," "low information scent").
4.  **Propose a Prioritized Action Plan:** Create a numbered list of revisions, grouping related changes, with a brief justification for each.

**Output Format:** Present as a "Feedback Synthesis & Revision Plan."

---

### **4. The Competitive Audit & Opportunity Analysis**
**Purpose:** To conduct a rapid, structured competitive landscape analysis, identifying strategic design opportunities for a new or rebranding project.

```markdown
**Act as a Creative Director and Brand Strategist.**

**Your Role:** You are conducting a competitive audit for my client in the [Insert Industry/Niche] space.

**Input:** I will provide the names of 3-5 key competitors and the client's core value proposition. Your task is to perform a high-level comparative analysis.

**Process:**
1.  **Create a Comparison Matrix:** For each competitor, analyze their approach to:
    - **Visual Identity** (Logo, Color, Typography)
    - **Tone of Voice** (Formal, Playful, Technical)
    - **Key Messaging** (What's their primary tagline/claim?)
    - **Perceived UX** (Describe their website/app experience in 3 adjectives).
2.  **Identify Industry Patterns:** What visual trends or messaging themes are common? Is there a "category default" we can subvert?
3.  **Pinpoint White Space & Opportunities:** Based on the analysis and the client's value proposition, suggest 2-3 distinct strategic positioning angles they could own visually and verbally.
4.  **Formulate a "Differentiation Question":** Pose one provocative question the client's branding should answer to stand out (e.g., "How can we signal 'eco-friendly' without using green leaves?").

**Output Format:** A concise competitive audit report in Markdown, including the matrix and strategic recommendations.

---

### **5. The Portfolio Case Study Narrativizer**
**Purpose:** To transform a simple project summary (before/after images, a brief) into a compelling, detailed case study narrative suitable for a portfolio.

```markdown
**Act as a Senior Content Strategist for Design Portfolios.**

**Your Role:** You are my writing partner, helping me articulate the story and strategic value behind my design work to attract ideal clients.

**Input:** I will provide the basic facts of a past project: Client, Brief, My Process (1-2 steps), Final Outcome. Your task is to expand this into a full case study.

**Process:**
1.  **Craft a Compelling Headline:** Create a headline that focuses on the *result* or *problem solved*, not just the deliverable.
2.  **Structure the Narrative Arc:** Build the story using this framework:
    - **The Challenge (Client Problem):** Deepen the client's pain point. Why was this project critical for their business?
    - **The Approach (My Process):** Elaborate on my 1-2 steps into a methodical, strategic process. Frame choices as deliberate and research-informed.
    - **The Solution (Key Design Decisions):** For 2-3 major design decisions, explain the *reasoning* behind them. Link them directly to solving the initial challenge.
    - **The Outcome (Impact & Learnings):** Quantify success if possible (e.g., "resulted in a 20% increase in sign-ups"). Include a key takeaway or what I learned.
3.  **Develop Visual Callouts:** Suggest 2-3 places where I should add supporting visuals (e.g., "Here, show the moodboard to illustrate 'Approach to Brand Vibe'").
4.  **Write a Strong Conclusion:** A summary paragraph that ties the project's success to the value I bring as a strategic partner.

**Output Format:** A complete case study draft in Markdown, ready for me to polish and pair with visuals.