# Standard Operating Procedure: Client Onboarding & Project Kickoff

**Purpose:** To ensure a consistent, professional start to every client engagement, setting clear expectations and minimizing scope creep.
**Owner:** Freelance Designer

---

## **1. Initial Inquiry & Qualification (Day 0)**
*   **Step 1.1:** Receive client inquiry via designated channel (e.g., email, website contact form).
*   **Step 1.2:** Respond within 24 business hours with a **pre-qualification questionnaire** (link to Typeform/Google Form). Key questions:
    *   Project overview & business goals.
    *   Target audience.
    *   Budget range (provide bracket options).
    *   Timeline expectations.
    *   How they found you (referral source).
*   **Step 1.3:** Review submission. If qualified (budget/timeline aligns), proceed to Step 1.4. If not, send a polite "not a fit" email with referrals if possible.
*   **Step 1.4:** Schedule a 30-minute "Discovery Call" via Calendly (or similar), blocking time only after questionnaire review.

## **2. Discovery & Scope Definition (Day 1-3)**
*   **Step 2.1:** Conduct Discovery Call. Use the **"Problem, Process, Product"** framework:
    *   **Problem:** Understand their core business challenge the design must solve.
    *   **Process:** Discuss their involvement, feedback loops, and approval authority.
    *   **Product:** Define the exact deliverables (e.g., "3 logo concepts," "10-page website mockup in Figma").
*   **Step 2.2:** Within 24 hours of the call, send a **"Project Understanding & Next Steps"** email summarizing key points, deliverables, and your proposed process. Request confirmation.
*   **Step 2.3:** Create a **Project Proposal & Statement of Work (SOW)** document. Must include:
    *   Project Summary & Goals.
    *   Detailed Scope of Work (Deliverables List).
    *   Timeline with Milestones (e.g., "Concept Presentations," "Final Files Delivery").
    *   Investment & Payment Schedule (e.g., 50% upfront, 50% on completion).
    *   Process & Communication Plan (e.g., "Feedback via Figma comments," "Bi-weekly check-ins").
    *   Assumptions & Exclusions (e.g., "Copywriting not included," "Up to 3 revision rounds per deliverable").
    *   **Link to Full Contract & Terms.**

## **3. Formal Agreement & Intake (Day 4-5)**
*   **Step 3.1:** Send the Proposal/SOW and separate **Service Agreement/Contract** (e.g., via HelloSign/PandaDoc) for e-signature.
*   **Step 3.2:** Upon signed contract and receipt of first payment (invoice sent via accounting software), initiate **Client Intake**:
    *   Create a dedicated folder in your project management system (e.g., Asana/Trello) with the project name.
    *   Send a **"Client Welcome & Onboarding Pack"** email containing:
        *   Link to a shared communication channel (e.g., Slack workspace, dedicated Discord channel).
        *   Link to a shared folder for asset collection (e.g., Google Drive/Dropbox).
        *   A brief questionnaire for brand assets, existing materials, and login credentials if needed.
        *   Your calendar link for scheduling future meetings.

---
# Standard Operating Procedure: Design Project Execution & Feedback Loop

**Purpose:** To manage the creative process efficiently, maintain control of revisions, and ensure client alignment at key stages.
**Owner:** Freelance Designer

---

## **1. Project Brief & Research (Kickoff - Week 1)**
*   **Step 1.1:** Host a 60-minute **Project Kickoff Meeting**. Agenda:
    *   Review goals, deliverables, and timeline from SOW.
    *   Walk through the project management board and communication plan.
    *   Present initial mood boards or research findings to ensure creative direction alignment.
*   **Step 1.2:** Finalize the **Creative Brief** document based on the kickoff discussion. This becomes the single source of truth.
*   **Step 1.3:** Set up the project workspace: initialize design files (Figma/Sketch), set up folders, and establish naming conventions (e.g., `YYYY-MM-DD_ProjectName_Concept_v1`).

## **2. Design Execution & Internal Review (Week 2-3)**
*   **Step 2.1:** Develop concepts based on the approved brief.
*   **Step 2.2:** Before client presentation, conduct a **self-review** using a checklist:
    *   Does it solve the core problem defined in the brief?
    *   Is it aligned with the target audience and brand?
    *   Are technical specs (size, format) correct?
*   **Step 2.3:** Prepare presentation materials. For each deliverable, create a **context slide** that explains the rationale behind key design choices, linking them back to the brief goals.

## **3. Client Presentation & Structured Feedback (Week 3-4)**
*   **Step 3.1:** Schedule a 45-minute **Concept Presentation Call**. Do not send files ahead of time.
*   **Step 3.2:** Present concepts live, walking through the rationale for each.
*   **Step 3.3:** After the call, upload concepts to the designated feedback platform (e.g., **Figma comments**, **InVision**, or a structured **Google Form**). Send an email with clear instructions:
    *   *"Please provide consolidated feedback via the link below by [Date/Time]. This helps ensure all feedback is captured accurately."*
    *   In the form/notes, request: **"For each change, please specify: 1. The location, 2. The desired change, 3. The reason (linking to the brief if possible)."**
*   **Step 3.4:** Acknowledge receipt of feedback and provide a revised timeline if the feedback is substantial.

## **4. Revision Management & Finalization (Week 4-5)**
*   **Step 4.1:** Implement feedback for one revision round. If feedback is unclear or conflicting, request a **"Feedback Clarification Call"** (15-20 mins).
*   **Step 4.2:** Present revisions. Repeat Steps 3.3 and 4.1 for subsequent rounds, tracking rounds against the SOW limit.
*   **Step 4.3:** Upon **final approval** (via a formal "sign-off" email or checklist), proceed to production. Send a **"Final Approval Confirmation"** email listing the approved files and next steps for file delivery.

---
# Standard Operating Procedure: Project Closure & Offboarding

**Purpose:** To professionally conclude projects, ensure all deliverables are handed over, and secure ongoing client relationships.
**Owner:** Freelance Designer

---

## **1. Final Delivery & Documentation (Post-Approval)**
*   **Step 1.1:** Prepare final files according to the SOW deliverables list. Use a clear folder structure (e.g., `/Print`, `/Web`, `/Source Files`).
*   **Step 1.2:** Create a **"Project Handoff Guide"** (1-page PDF or Notion page). Include:
    *   File inventory and brief description of each.
    *   Key design decisions, font names, color codes (HEX/RGB).
    *   Instructions for basic edits or usage (if applicable).
*   **Step 1.3:** Deliver files via the shared folder. Send a **"Final Delivery & Handoff"** email with:
    *   Link to files.
    *   Link to the Handoff Guide.
    *   A request for a final "everything looks good" confirmation.
    *   The final invoice (if the last payment is milestone-based).

## **2. Project Review & Testimonial (Within 3 Days of Closure)**
*   **Step 2.1:** Send a **"Project Wrap-Up"** email containing:
    *   A link to a short **feedback form** (3-5 questions: What went well? What could be improved? Overall satisfaction?).
    *   A request for a **LinkedIn recommendation or testimonial**. Provide a template or key questions to make it easy.
*   **Step 2.2:** Log key learnings, templates, and assets from the project in your internal knowledge base (e.g., Notion) for future reference.

## **3. Long-Term Relationship & Offboarding (1 Week Post-Closure)**
*   **Step 3.1:** Add the client to your **CRM** (even a spreadsheet) with notes on project outcomes and their feedback.
*   **Step 3.2:** Add them to a **"Past Clients" email segment** for your occasional newsletter or valuable updates.
*   **Step 3.3:** Set a **calendar reminder** for a "check-in" 60-90 days post-project. Plan a brief, value-driven email (e.g., sharing an article relevant to their industry) to stay top-of-mind for future needs or referrals.
*   **Step 3.4:** Archive the project folder in your project management system and cloud storage, but keep it accessible. Update your portfolio with the project (with permission).